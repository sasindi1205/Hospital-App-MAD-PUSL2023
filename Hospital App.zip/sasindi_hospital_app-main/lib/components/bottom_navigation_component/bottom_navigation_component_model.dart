import '/hospital_app/hospital_app_util.dart';
import 'bottom_navigation_component_widget.dart'
    show BottomNavigationComponentWidget;
import 'package:flutter/material.dart';

class BottomNavigationComponentModel
    extends hospitalAppModel<BottomNavigationComponentWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
