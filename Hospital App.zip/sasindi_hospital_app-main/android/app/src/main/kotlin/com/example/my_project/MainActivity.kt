package com.mycompany.hospitalapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
