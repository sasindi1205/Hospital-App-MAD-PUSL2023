import '/hospital_app/hospital_app_util.dart';
import 'change_photo_widget.dart' show ChangePhotoWidget;
import 'package:flutter/material.dart';

class ChangePhotoModel extends hospitalAppModel<ChangePhotoWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
